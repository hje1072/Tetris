package main_battle;

import main.*;

public class PlayManger_2 extends PlayManager{
	
}
